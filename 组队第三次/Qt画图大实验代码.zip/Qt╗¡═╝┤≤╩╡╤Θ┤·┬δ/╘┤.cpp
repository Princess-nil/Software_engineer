Dawningtool.h
#ifndef DRAWINGTOOL_H
#define DRAWINGTOOL_H

#include <QPixmap>
#include <QPainter>
#include <QColor>
#include <QString>
#include <QDebug>
#include <QStack>
#include <QtSvg/QSvgGenerator>
#include <QtSvg/QSvgRenderer>

#define MAX_STACK 65535
#define MAX_PIXMAP_WIDTH 1000
#define MAX_PIXMAP_HEIGHT 700
#define DOCK_WIDGET_WIDTH 200
#define INITIAL_PEN_WIDTH 3
#define END_PEN_WIDTH 17
#define INITIAL_ERASER_WIDTH 3
#define END_ERASER_WIDTH 17

enum ShapeEnum { DEFAULT, STRAIGHT, RECTANGULAR, CIRCULAR };
enum PenTypeEnum { PENCIL, ERASER };

class DrawingTool
{
public:
	DrawingTool(int width = MAX_PIXMAP_WIDTH, int height = MAX_PIXMAP_HEIGHT);
	~DrawingTool();

	void setDownPixmapColor(QColor color);

	ShapeEnum getShape();
	void setShape(ShapeEnum choice);

	PenTypeEnum getPenType();
	void setPenType(PenTypeEnum penType);

	QColor getPenColor();
	int getPenWidth();
	void setPen(int width);
	void setPen(QColor color);
	void setPen(Qt::PenStyle);
	void setPen(QColor color, int width);

	int getEraserWidth();
	void setEraser(int width);

	void choice(ShapeEnum shape, int lastX, int lastY, int endX, int endY);
	void drawShape(QPaintDevice *device, ShapeEnum shape, bool isDrawing, int &lastX, int &lastY, int &endX, int &endY);

	void savePngOrJpg(QString filePath);
	void saveSvg(QString filePath);
	void openSvg(QString filePath);

	bool isStackEmpety();
	void stackPush();//ѹ�뵱ǰ��primarypixmap
	void backout(QPaintDevice *device);//��������

	void reform();

private:
	QPixmap downPixmap;//�ײ㻭��
	QPixmap primaryPixmap;//������
	QPixmap assistPixmap;//��������
	QPixmap savePixmap;//���滭��

	QPainter primaryPainter;//������
	QPainter assistPainter;//��������

						   //����ͼ��
	ShapeEnum shape;

	//����
	QPen pen;
	QPen eraser;
	PenTypeEnum currentPen;//��ǰ����

						   //����ջ
	QStack<QPixmap> stack;
};

#endif // DRAWINGTOOL_H

Mainwindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QPainter>
#include <QMouseEvent>
#include <QLabel>
#include <QString>
#include <QColorDialog>
#include "drawingtool.h"
#include <QDebug>
#include <QFileDialog>
#include <QMessageBox>
#include <QCursor>
#include <QtSvg/QSvgRenderer>
#include <QtSvg/QSvgGenerator>

#define SHOW_MESSAGE_TIME 3000
#define DOCK_WIDGET_WIDTH 200
#define DEFAULT_WIDTH 1000
#define DEFAULT_HEIGHT 700

enum PenStyleEnum { SOLIDLINT, DASHLINE, DONTLINE };

namespace Ui {
	class MainWindow;
}

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	explicit MainWindow(int width = DEFAULT_WIDTH, int height = DEFAULT_HEIGHT, QWidget *parent = 0);
	~MainWindow();

protected:
	void paintEvent(QPaintEvent *);

	void mousePressEvent(QMouseEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
	void mouseReleaseEvent(QMouseEvent *event);

	QString cssFromColor(QColor color);
	void saveFile();

private:
	void recoverDefault(PenTypeEnum type, bool isComBox, bool isComBoxStyle);

	private slots:
	void on_actionNew_triggered();
	void on_actionOpen_triggered();
	void on_actionSave_triggered();
	void on_actionSaveAs_triggered();

	void on_comboBox_activated(int index);
	void on_comboBoxStyle_activated(int index);

	void on_pushButtonColor_clicked();
	void on_pushButtonBackgroundColor_clicked();

	void on_SliderWidth_valueChanged(int value);
	void on_pushButtonSub_clicked();
	void on_pushButtonAdd_clicked();

	void on_SliderWidthEraser_valueChanged(int value);
	void on_pushButtonSubEraser_clicked();
	void on_pushButtonAddEraser_clicked();

	void on_pushButtonPen_clicked();
	void on_pushButtonEraser_clicked();

	void on_pushButtonUndo_clicked();
	void on_pushButtonReform_clicked();

	void on_actionUndo_triggered();
	void on_actionReform_triggered();

	void on_actionAboutDrawingBoard_triggered();

private:
	Ui::MainWindow *ui;

	//�������
	int lastX;
	int lastY;
	int endX;
	int endY;

	bool isDrawing;  //��־�Ƿ����ڻ�ͼ
	bool isBackout;  //��־�Ƿ���
	bool isSaved;    //��־�Ƿ񱣴��

	DrawingTool *tool;

	QString filePath; //�ļ�����·��

					  //״̬����Ϣ
	QStatusBar *sBarPermanent;
	QStatusBar *sBarTemporary;
};

#endif // MAINWINDOW_H

Drawingtool.cpp
#include "drawingtool.h"

DrawingTool::DrawingTool(int width, int height)
{
	//�ײ㻭������
	downPixmap = QPixmap(width, height);
	downPixmap.fill(Qt::white);//�ײ㻭��Ϊ��ɫ

	primaryPixmap = QPixmap(width, height);//������С
	primaryPixmap.fill(Qt::transparent);//���������Ϊ͸��ɫ

	savePixmap = QPixmap(width, height);

	//��ʼ��������
	currentPen = PENCIL;
	shape = DEFAULT;

	//���ʵĻ�������
	pen.setCapStyle(Qt::RoundCap);
	pen.setJoinStyle(Qt::RoundJoin);
	pen.setColor(Qt::black);
	pen.setWidth(INITIAL_PEN_WIDTH);

	//��Ƥ�Ļ�������
	eraser.setCapStyle(Qt::RoundCap);
	eraser.setJoinStyle(Qt::RoundJoin);
	eraser.setColor(Qt::transparent);//͸��ɫ
	eraser.setWidth(INITIAL_ERASER_WIDTH);

	stack.push(primaryPixmap);
}

DrawingTool::~DrawingTool() {}

void DrawingTool::setDownPixmapColor(QColor color)
{
	if (color.isValid() == false)
		return;
	downPixmap.fill(color);
}

ShapeEnum DrawingTool::getShape()
{
	return shape;
}

void DrawingTool::setShape(ShapeEnum choice)
{
	shape = choice;
}

PenTypeEnum DrawingTool::getPenType()
{
	return currentPen;
}

void DrawingTool::setPenType(PenTypeEnum PenType)
{
	currentPen = PenType;
}

QColor DrawingTool::getPenColor()
{
	return pen.color();
}

int DrawingTool::getPenWidth()
{
	return pen.width();
}

void DrawingTool::setPen(int width)
{
	if (width <= 0)
		return;
	pen.setWidth(width);
}

void DrawingTool::setPen(QColor color)
{
	if (color.isValid() == false)
		return;
	pen.setColor(color);
}

void DrawingTool::setPen(Qt::PenStyle style)
{
	pen.setStyle(style);
}

void DrawingTool::setPen(QColor color, int width)
{
	if (color.isValid() == false && width <= 0)
		return;
	pen.setColor(color);
	pen.setWidth(width);
}

int DrawingTool::getEraserWidth()
{
	return eraser.width();
}

void DrawingTool::setEraser(int width)
{
	if (width <= 0)
		return;
	eraser.setWidth(width);
}

void DrawingTool::choice(ShapeEnum shape, int lastX, int lastY, int endX, int endY)
{
	switch (shape)
	{
	case DEFAULT:
	case STRAIGHT:
		assistPainter.drawLine(lastX, lastY, endX, endY);
		break;
	case RECTANGULAR:
		assistPainter.drawRect(lastX, lastY, endX - lastX, endY - lastY);
		break;
	case CIRCULAR:
		assistPainter.drawEllipse(lastX, lastY, endX - lastX, endY - lastY);
		break;
	}
}

void DrawingTool::drawShape(QPaintDevice *device, ShapeEnum shape, bool isDrawing,
	int &lastX, int &lastY, int &endX, int &endY)
{
	if (device == nullptr)
		return;
	primaryPainter.begin(device);
	primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, downPixmap);//���Ƶײ㻭��
	if (shape == DEFAULT || isDrawing != true) //�����DEFAULTֱ�����������ϻ�ͼ
	{
		assistPainter.begin(&primaryPixmap);
		assistPainter.setRenderHint(QPainter::Antialiasing, true);//�������Ⱦ

		if (currentPen == PENCIL) {
			assistPainter.setCompositionMode(QPainter::CompositionMode_SourceOver);//��ɫ
			assistPainter.setPen(pen); //���ӻ���
		}
		else {
			assistPainter.setCompositionMode(QPainter::CompositionMode_Clear);
			assistPainter.setPen(eraser);
		}
		choice(shape, lastX, lastY, endX, endY);
		assistPainter.end();

		primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, primaryPixmap);
		lastX = endX;//�����ε�������Ϊ��һ�����꣬��֤���������ġ�
		lastY = endY;
	}
	else//������ڻ�ͼ�����ڸ��������ϻ���
	{
		assistPixmap = primaryPixmap;//����ǰpix�е����ݸ��Ƶ�tempPix�У���֤��ǰ�����ݲ���ʧ

		assistPainter.begin(&assistPixmap);
		assistPainter.setRenderHint(QPainter::Antialiasing, true);//�������Ⱦ
		assistPainter.setPen(pen); //���ӻ���
		choice(shape, lastX, lastY, endX, endY);
		assistPainter.end();

		primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, assistPixmap);
	}
	primaryPainter.end();
}

void DrawingTool::savePngOrJpg(QString filePath)
{
	if (filePath.isEmpty() == true)
		return;
	primaryPainter.begin(&savePixmap);
	primaryPainter.drawPixmap(0, 0, downPixmap);
	primaryPainter.drawPixmap(0, 0, primaryPixmap);
	primaryPainter.end();
	savePixmap.save(filePath);
}

void DrawingTool::saveSvg(QString filePath)
{
	if (filePath.isEmpty() == true)
		return;
	QSvgGenerator generator;
	generator.setFileName(filePath);

	int width = primaryPixmap.width();
	int height = primaryPixmap.height();
	generator.setSize(QSize(width, height));
	generator.setViewBox(QRect(DOCK_WIDGET_WIDTH, 0, width, height));

	primaryPainter.begin(&generator);
	primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, primaryPixmap);//���ػ���
	primaryPainter.end();
}

void DrawingTool::openSvg(QString filePath)
{
	if (filePath.isEmpty() == true)
		return;
	reform();
	QSvgRenderer Converter;
	Converter.load(filePath);
	primaryPainter.begin(&primaryPixmap);
	Converter.render(&primaryPainter);
	primaryPainter.drawPixmap(0, 0, primaryPixmap);
	primaryPainter.end();
}

bool DrawingTool::isStackEmpety()
{
	return stack.empty();
}

void DrawingTool::stackPush()
{
	if (stack.count() > MAX_STACK)
		stack.clear();
	stack.push(primaryPixmap);
}

void DrawingTool::backout(QPaintDevice *device)
{
	if (device == nullptr)
		return;
	primaryPainter.begin(device);
	primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, downPixmap);//�Ȼ��Ƶײ㻭��
	primaryPainter.drawPixmap(DOCK_WIDGET_WIDTH, 0, stack.top());//���ػ���
	primaryPainter.end();
	primaryPixmap = stack.top();
	stack.pop();
}

void DrawingTool::reform()
{
	primaryPixmap.fill(Qt::transparent);//�������Ϊ͸��ɫ
}

Main.cpp
#include "mainwindow.h"
#include <QApplication>
#include <QStyleFactory>
#include <QDesktopWidget>
#include <QDebug>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	a.setStyle(QStyleFactory::create("fusion"));
	QDesktopWidget *desktopWidget = a.desktop();
	QRect screenRect = desktopWidget->screenGeometry();
	int width = screenRect.width();
	int height = screenRect.height();
	MainWindow w(width, height);
	//w.move(-10,0);
	w.show();

	return a.exec();
}

Mainwindow.cpp
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(int width, int height, QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);

	setWindowTitle("����");
	int poorHeight = ui->menuBar->height() + ui->statusBar->height() + iconSize().height();//��������ʾ���߶ȵĲ�
	setFixedSize(width, height - poorHeight);
	setWindowIcon(QIcon(":/new/logo.png"));

	tool = new DrawingTool(width, height - poorHeight);

	lastX = 0; lastY = 0; endX = 0; endY = 0;

	isDrawing = false;
	isBackout = false;
	isSaved = false;

	ui->menuBar->setStyleSheet("background-color: rgb(200, 200, 200);");
	ui->dockWidget->setStyleSheet("background-color: rgb(230, 230, 230);");
	ui->statusBar->setStyleSheet("background-color: rgb(200, 200, 200);");
	ui->pushButtonColor->setStyleSheet("background-color: rgb(0, 0, 0);");
	ui->pushButtonBackgroundColor->setStyleSheet("background-color: rgb(255, 255, 255);");
	ui->pushButtonSub->setStyleSheet("border-radius:21px;background-image: url(:/new/sub.png)");
	ui->pushButtonAdd->setStyleSheet("border-radius:21px;background-image: url(:/new/add.png)");
	ui->pushButtonSubEraser->setStyleSheet("border-radius:21px;background-image: url(:/new/sub.png)");
	ui->pushButtonAddEraser->setStyleSheet("border-radius:21px;background-image: url(:/new/add.png)");
	ui->comboBoxStyle->setEnabled(false);

	//״̬��
	sBarPermanent = statusBar();
	sBarPermanent->addPermanentWidget(new QLabel("Drawing Board", this));
	sBarTemporary = statusBar();
	sBarTemporary->showMessage("PenType��Pencil��Shape��DEFAULT", SHOW_MESSAGE_TIME);
}

MainWindow::~MainWindow()
{
	delete ui;
	delete tool;
	delete sBarPermanent;
}

void MainWindow::paintEvent(QPaintEvent *)
{
	if (isBackout == true) {
		tool->backout(this);
		isBackout = false;
	}
	else {
		tool->drawShape(this, tool->getShape(), isDrawing, lastX, lastY, endX, endY);
	}
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton)//��������������
	{
		lastX = event->pos().x() - DOCK_WIDGET_WIDTH;
		lastY = event->pos().y();
	}
	if (lastX >= 0)
		tool->stackPush();
	endX = lastX; endY = lastY;//��һ�д�������⣬���˺þ�
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
	if (event->buttons() & Qt::LeftButton)//����갴��������ƶ���ʱ��,ע��������buttons
	{
		endX = event->pos().x() - DOCK_WIDGET_WIDTH;
		endY = event->pos().y();
		isDrawing = true;   //���ڻ�ͼ
		update();//���»���
	}
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton)//���������ͷ�
	{
		endX = event->pos().x() - DOCK_WIDGET_WIDTH;
		endY = event->pos().y();
		isDrawing = false;    //������ͼ
		update();//���»���
	}
}

QString MainWindow::cssFromColor(QColor color)
{
	if (color.isValid() == false)
		return nullptr;

	int r, g, b;
	color.getRgb(&r, &g, &b);
	return QString("background-color: rgb(%1, %2, %3);").arg(r).arg(g).arg(b);
}

void MainWindow::on_actionNew_triggered()
{
	QMessageBox *messageBox = new QMessageBox(this);
	messageBox->setIcon(QMessageBox::Warning);
	messageBox->setWindowTitle("ȷ��");
	messageBox->setText("�½����彫��յ�ǰ���壬�Ƿ�ȷ���½���");
	messageBox->addButton("ȡ��", QMessageBox::RejectRole);
	messageBox->addButton("ȷ��", QMessageBox::AcceptRole);
	if (messageBox->exec() == QDialog::Accepted) { //�������ȷ����ť����ִ�������������
		on_pushButtonReform_clicked();
		isSaved = false;
	}
}

void MainWindow::saveFile()
{
	if (filePath.endsWith(".svg")) {
		tool->saveSvg(filePath);
	}
	else {
		tool->savePngOrJpg(filePath);
	}
}

void MainWindow::recoverDefault(PenTypeEnum type, bool isComBox, bool isComBoxStyle)
{
	tool->setPenType(type);
	tool->setShape(DEFAULT);
	tool->setPen(Qt::SolidLine);
	ui->comboBox->setCurrentIndex(DEFAULT);
	ui->comboBoxStyle->setCurrentIndex(SOLIDLINT);
	ui->comboBox->setEnabled(isComBox);
	ui->comboBoxStyle->setEnabled(isComBoxStyle);
}

void MainWindow::on_actionOpen_triggered()
{
	filePath = QFileDialog::getOpenFileName(this, "Open Svg", "", "SVG files (*.svg)");
	if (filePath == "")
		return;
	tool->openSvg(filePath);
	isSaved = true;
}

void MainWindow::on_actionSave_triggered()
{
	if (isSaved == true)
		saveFile();
	else
		on_actionSaveAs_triggered();
}

void MainWindow::on_actionSaveAs_triggered()
{
	filePath = QFileDialog::getSaveFileName(this, "Save Image", "",
		"PNG (*.png);;JPEG (*.jpg *.jpeg);"
		";SVG files (*.svg);;All files (*.*)");
	if (filePath == "")
		return;

	saveFile();
	isSaved = true;
}

void MainWindow::on_comboBox_activated(int index)
{
	switch (index)
	{
	case DEFAULT:
		tool->setShape(DEFAULT);
		tool->setPen(Qt::SolidLine);
		ui->comboBoxStyle->setCurrentIndex(SOLIDLINT);
		ui->comboBoxStyle->setEnabled(false);
		sBarTemporary->showMessage("Shape��DEFAULT", SHOW_MESSAGE_TIME);
		break;
	case STRAIGHT:
		tool->setShape(STRAIGHT);
		sBarTemporary->showMessage("Shape��STRAIGHT", SHOW_MESSAGE_TIME);
		ui->comboBoxStyle->setEnabled(true);
		break;
	case RECTANGULAR:
		tool->setShape(RECTANGULAR);
		sBarTemporary->showMessage("Shape��RECTANGULAR", SHOW_MESSAGE_TIME);
		ui->comboBoxStyle->setEnabled(true);
		break;
	case CIRCULAR:
		tool->setShape(CIRCULAR);
		sBarTemporary->showMessage("Shape��CIRCULAR", SHOW_MESSAGE_TIME);
		ui->comboBoxStyle->setEnabled(true);
		break;
	default:
		break;
	}
}

void MainWindow::on_comboBoxStyle_activated(int index)
{
	switch (index)
	{
	case SOLIDLINT:
		tool->setPen(Qt::SolidLine);
		break;
	case DASHLINE:
		tool->setPen(Qt::DashLine);
		break;
	case DONTLINE:
		tool->setPen(Qt::DotLine);
		break;
	default:
		break;
	}
}

void MainWindow::on_pushButtonColor_clicked()
{
	QColor color = QColorDialog::getColor(Qt::black, this, "��ɫ��");
	if (color.isValid() == false)//���õ�ɫ��ѡ��cancelʱ����ɫ
		color = tool->getPenColor();

	tool->setPen(color);
	QString style = cssFromColor(color);
	ui->pushButtonColor->setStyleSheet(style);
}

void MainWindow::on_pushButtonBackgroundColor_clicked()
{
	QColor color = QColorDialog::getColor(Qt::white, this, "��ɫ��");
	if (color.isValid() == false)//���õ�ɫ��ѡ��cancelʱ����ɫ
		color = ui->pushButtonBackgroundColor->palette().color(QPalette::Background);

	tool->setDownPixmapColor(color);
	QString style = cssFromColor(color);
	ui->pushButtonBackgroundColor->setStyleSheet(style);
}

void MainWindow::on_SliderWidth_valueChanged(int value)
{
	tool->setPen(value);
	ui->labelWidthNum->setText(QString::number(value - INITIAL_PEN_WIDTH + 1));
}

void MainWindow::on_pushButtonSub_clicked()
{
	int width = tool->getPenWidth() - 1;
	if (width < INITIAL_PEN_WIDTH)
		return;
	ui->SliderWidth->setValue(width);
	on_SliderWidth_valueChanged(width);
}

void MainWindow::on_pushButtonAdd_clicked()
{
	int width = tool->getPenWidth() + 1;
	if (width > END_PEN_WIDTH)
		return;
	ui->SliderWidth->setValue(width);
	on_SliderWidth_valueChanged(width);
}

void MainWindow::on_SliderWidthEraser_valueChanged(int value)
{
	tool->setEraser(value);
	ui->labelWidthNumEraser->setText(QString::number(value - INITIAL_ERASER_WIDTH + 1));
}

void MainWindow::on_pushButtonSubEraser_clicked()
{
	int width = tool->getEraserWidth() - 1;
	if (width < INITIAL_ERASER_WIDTH)
		return;
	ui->SliderWidthEraser->setValue(width);
	on_SliderWidthEraser_valueChanged(width);
}

void MainWindow::on_pushButtonAddEraser_clicked()
{
	int width = tool->getEraserWidth() + 1;
	if (width > END_ERASER_WIDTH)
		return;
	ui->SliderWidthEraser->setValue(width);
	on_SliderWidthEraser_valueChanged(width);;
}

void MainWindow::on_pushButtonPen_clicked()
{
	this->setCursor(Qt::ArrowCursor);//�л�����ͷ��״
	recoverDefault(PENCIL, true, false);
	sBarTemporary->showMessage("PenType��PENCIL", SHOW_MESSAGE_TIME);
}

void MainWindow::on_pushButtonEraser_clicked()
{
	QCursor *myCursor = new QCursor(QPixmap(":/new/eraser.png"), -1, -1);//-1,-1��ʾ�ȵ�λ��ͼƬ����
	this->setCursor(*myCursor);
	recoverDefault(ERASER, false, false);
	sBarTemporary->showMessage("PenType��ERASER", SHOW_MESSAGE_TIME);
}

void MainWindow::on_pushButtonUndo_clicked()
{
	if (tool->isStackEmpety() == true)
		return;
	isBackout = true;
	update();
}

void MainWindow::on_pushButtonReform_clicked()
{
	tool->stackPush();
	tool->reform();
	update();
}

void MainWindow::on_actionUndo_triggered()
{
	on_pushButtonUndo_clicked();
}

void MainWindow::on_actionReform_triggered()
{
	on_pushButtonReform_clicked();
}

void MainWindow::on_actionAboutDrawingBoard_triggered()
{
	QMessageBox::about(this, "����DrawingBoard", "�������Ĵ�ʵ��");
}
